package com.springboot.studentDataManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentDataManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
