package com.springboot.studentDataManagementSystem.dtos;

import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class GroupResponse {
	 private String groupBy;           // Attribute used for grouping
	 private Map<String, Long> results; // Grouped results: {groupValue: count}
}
