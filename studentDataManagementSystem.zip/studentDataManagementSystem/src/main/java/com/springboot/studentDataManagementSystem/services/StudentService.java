package com.springboot.studentDataManagementSystem.services;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.studentDataManagementSystem.Entity.Student;
import com.springboot.studentDataManagementSystem.repositories.StudentRepository;

@Service
public class StudentService {
	
	@Autowired
    private StudentRepository studentRepository;
	
	/**
	 * Add a new student to the database.
	 *
	 * @param student The student data to be added
	 * @return The saved student with a generated ID
	 */
	public Student addStudent(Student student) {
	    return studentRepository.save(student);
	}
	
	

    /**
     * Retrieve all students from the database.
     *
     * @return List of all students
     */
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    /**
     * Filter students based on the provided filters.
     *
     * @param filters A map of filters (key-value pairs)
     * @return A list of students matching the filters
     */
    public List<Student> filterStudents(Map<String, String> filters) {
        return studentRepository.findAll().stream()
                .filter(student -> matchesFilters(student, filters))
                .collect(Collectors.toList());
    }

    /**
     * Group students based on a specified attribute.
     *
     * @param students The list of students to group
     * @param groupBy  The attribute to group by
     * @return A map where the key is the group value, and the value is the count of students in that group
     */
    public Map<String, Long> groupStudents(List<Student> students, String groupBy) {
        return students.stream()
                .collect(Collectors.groupingBy(student -> getFieldValue(student, groupBy), Collectors.counting()));
    }

    /**
     * Helper method to check if a student matches all filters.
     *
     * @param student The student object
     * @param filters A map of filters
     * @return True if the student matches all filters; otherwise, false
     */
    private boolean matchesFilters(Student student, Map<String, String> filters) {
    	for (Map.Entry<String,String> entry : filters.entrySet()) {
            String fieldName = entry.getKey();
            Object filterValue = entry.getValue();
            Object studentFieldValue = getFieldValue(student, fieldName);

            if (filterValue instanceof List) {
                // Handle array-based filters (e.g., languages)
                List<?> filterList = (List<?>) filterValue;
                if (studentFieldValue instanceof List) {
                    List<?> studentList = (List<?>) studentFieldValue;
                    if (!studentList.containsAll(filterList)) {
                        return false;
                    }
                } else {
                    return false;
                }
            } else {
                // Handle simple filters (e.g., gender, nationality)
                if (!filterValue.toString().equalsIgnoreCase(studentFieldValue.toString())) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Helper method to get the value of a field from a Student object using reflection.
     *
     * @param student The student object
     * @param fieldName The field name to retrieve
     * @return The field value as a string, or "Unknown" if the field is not found
     */
    private String getFieldValue(Student student, String fieldName) {
        try {
            Field field = Student.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            Object value = field.get(student);
            return value != null ? value.toString() : "Unknown";
        } catch (Exception e) {
            return "Unknown";
        }
    }
}
