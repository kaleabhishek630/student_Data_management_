package com.springboot.studentDataManagementSystem.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.studentDataManagementSystem.Entity.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {

	List<Student> findAll();

}
