package com.springboot.studentDataManagementSystem.Entity;

import java.util.List;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="students")
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter

public class Student {

	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id; // Primary Key

	    @Column(nullable = false, unique = true)
	    private String rollNumber; // Unique Roll Number

	    @Column(nullable = false)
	    private String name; // Student Name

	    private String dob; // Date of Birth in "yyyy-MM-dd" format

	    private String gender; // Gender 

	    private String nationality; // Nationality of the Student

	    private String familyIncome; // Family Income 

	    private String house; // House Assignment 

	    @ElementCollection
	    //[@CollectionTable(name = "student_languages", joinColumns = @JoinColumn(name = "student_id"))
	    @Column(name = "language")
	    private List<String> languages; // List of Languages the Student Knows

	    private String fatherName; // Father's Name
	    private String motherName; // Mother's Name
	    private String contactNumber; // Contact Number
	    private String address; // Home Address

	    private String admissionDate; // Admission Date in "yyyy-MM-dd"
}
