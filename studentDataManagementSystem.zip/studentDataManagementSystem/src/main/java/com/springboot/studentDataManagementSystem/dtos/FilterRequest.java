package com.springboot.studentDataManagementSystem.dtos;

import java.util.List;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class FilterRequest {
	private Map<String, String> filter; // Key-Value pairs for filtering conditions
    private List<String> groupBy;      // List of attributes to group by  vcx
    public Map<String, String> getFilter() {
        return filter;
    }

    public void setFilter(Map<String, String> filter) {
        this.filter = filter;
    }

    public List<String> getGroupBy() {
        return groupBy;
    }

    public void setGroupBy(List<String> groupBy) {
        this.groupBy = groupBy;
    }
}
