package com.springboot.studentDataManagementSystem.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.studentDataManagementSystem.Entity.Student;
import com.springboot.studentDataManagementSystem.dtos.FilterRequest;
import com.springboot.studentDataManagementSystem.dtos.GroupResponse;
import com.springboot.studentDataManagementSystem.services.StudentService;

@RestController
@RequestMapping("/students")
public class StudentController {
	 @Autowired
	    private StudentService studentService;
	 
	 /**
	  * Endpoint to add a new student to the database.
	  *
	  * @param student The student data to be added
	  * @return The added student with a generated ID
	  */
	 @PostMapping
	 public Student addStudent(@RequestBody Student student) {
	     return studentService.addStudent(student);
	 }
	 

	    /**
	     * Endpoint to retrieve all students.
	     *
	     * @return List of all students
	     */
	    @GetMapping
	    public List<Student> getAllStudents() {
	        return studentService.getAllStudents();
	    }

	    /**
	     * Endpoint to filter students based on conditions.
	     *
	     * @param filters A map of filters (key-value pairs)
	     * @return List of students matching the filters
	     */
	    @PostMapping("/filter")
	    public List<Student> filterStudents(@RequestBody Map<String, String> filters) {
	        return studentService.filterStudents(filters);
	    }

	    /**
	     * Endpoint to group students based on a specific attribute.
	     *
	     * @param request The request body containing filters and groupBy attributes
	     * @return GroupResponse containing the grouped results
	     */
	    @PostMapping("/group")
	    public GroupResponse groupStudents(@RequestBody FilterRequest request) {
	        // Filter students based on the request's filters
	        List<Student> filteredStudents = studentService.filterStudents(request.getFilter());

	        // Group students based on the first groupBy attribute
	        String groupBy = request.getGroupBy().get(0); // Take the first attribute for grouping
	        Map<String, Long> groupedResults = studentService.groupStudents(filteredStudents, groupBy);

	        // Return the response
	        return new GroupResponse(groupBy, groupedResults);
	    }
}
